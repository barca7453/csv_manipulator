g++ -g -o  csv csv_manipulator.cpp --std=c++0x
